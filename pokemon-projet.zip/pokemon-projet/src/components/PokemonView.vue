<template>
    <div class="center white-text">
        <div v-for="pokemon in getPokemon" :key="pokemon.name" role="display">
            <img v-bind:src="'/images/pokimage/' + pokemon.name + '.png'" alt="logo">
            <h3>Power:{{ pokemon.hp }}</h3>
            <h3> {{ pokemon.name }} </h3>
            <h5>japanese_name: {{ pokemon.japanese_name }}</h5>
            
     
        </div>
    </div>
</template>

<script>
export default{
    name:'pokemon-list',

    data(){
        return{
            params:this.$route.params.name
        }
    },
    computed:{
        getPokemon(){
            return this.$store.state.pokemons.filter( p => {
                return p.name.includes(this.params)
            })
        }
    }
}
</script>

<style scoped>
img{
    width: 15rem;
}



</style>