<template>
  <div class="col s12 m4">
    <div
      class="card-panel" role="pokemon-card-panel"
      :class="pokemon.type1"
      @mouseover="hover = true"
      @mouseleave="hover = false"
    >
      <div class="row">
        <h4>{{ pokemon.name }}</h4>
      </div>
      <div class="row">
        <img
          role="pokemon"
          v-bind:src="'/images/pokimage/' + pokemon.name + '.png'"
          alt="name.png"
        />
      </div>
      <div class="row">
        <h5>hp: {{ pokemon.hp }}</h5>
      </div>
      <div class="row">
        <h5>{{ pokemon.type1 }}</h5>
      </div>
      <router-link role="pokemon-btn"
        :to="{ name: 'pokemon-view', params: { name: pokemon.name } }"
      >
        <button v-if="hover" class="btn ocean center">VOIR LE POKEMON</button>
      </router-link>
    </div>
  </div>
</template>

<!-- <script>
export default {
  props: {
    pokemon: {
      type: Object,
      required: true
    },
    hover: {
      type: Boolean,
      required: true
    }
  }
  // ...
}
</script> -->

<script>
export default {
  name: "PoKemon",
  props: ["pokemon"],

  data() {
    return {
      type: null,
      hover: false,
    };
  },
};
</script>

<style scoped>
div[role="pokemon-card-panel"]{
  /* width: 80px; */
position: relative;

}
[role="pokemon-btn"]{
  /* width: 80px; */
position: absolute ;
left: 50%;
transform: translateX(-50%);

}
img[role="Type1"]{
  width: 80px;
}
.electrique {
  background-color: rgb(253, 253, 187);
}
.grass {
  background-color: rgb(180, 249, 180);
}
.fire {
  background-color: rgb(250, 197, 117);
}
.water {
  background-color: rgb(164, 205, 244);
}
.bug {
  background-color: rgb(239, 183, 183);
}
button {
  animation: buttonshow 0.4s;
}
button:hover {
  /* transform: scale(1.1); */
  transition: 0.4s;
}
@keyframes buttonshow {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}
</style>
